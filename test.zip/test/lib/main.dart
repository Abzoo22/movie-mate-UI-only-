import 'package:flutter/material.dart';
import 'package:test/pages/dune.dart';
import 'package:test/pages/fc.dart';
import 'package:test/pages/gf.dart';
import 'package:test/pages/home.dart';
import 'package:test/pages/login_page.dart';
import 'package:test/pages/op.dart';
import 'package:test/pages/profile.dart';
import 'package:test/pages/signup.dart';
import 'package:test/pages/watchlist.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'firebase_options.dart';
void main()async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
);
FirebaseFirestore.instance.settings = const Settings(
    persistenceEnabled: true);
runApp(Myapp());
}
class Myapp extends StatelessWidget{  
  const Myapp({super.key});
  @override
Widget build(BuildContext context){
return const MaterialApp(
home :LoginPage(),
);
}
}
