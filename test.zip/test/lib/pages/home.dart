import 'package:flutter/material.dart';
import 'package:test/pages/br.dart';
import 'package:test/pages/dune.dart';
import 'package:test/pages/fc.dart';
import 'package:test/pages/gf.dart';
import 'package:test/pages/op.dart';
import 'package:test/pages/profile.dart';
import 'package:test/pages/watchlist.dart';

class homepage extends StatelessWidget {
  const homepage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],

      appBar: AppBar(
        backgroundColor: Colors.grey[300],
        elevation: 0,
        actions: [  
          PopupMenuButton<String>(
            icon: const Icon(Icons.menu, color: Colors.black),
            onSelected: (value) {
              if (value == 'profile') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Profile()),
                );
              } else if (value == 'watchlist') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const watch()), 
                );
              } else if (value == 'logout') {
                
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Logged out')),
                );
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'profile', child: Text('User Profile')),
              const PopupMenuItem(value: 'watchlist', child: Text('Watchlist')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      ),

      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
          
              TextField(
                decoration: InputDecoration(
                  hintText: 'Search for movies...',
                  prefixIcon: const Icon(Icons.search),
                  filled: true,
                  fillColor: Colors.grey[200],
                  enabledBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.white),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderSide: const BorderSide(color: Colors.blue),
                    borderRadius: BorderRadius.circular(10),
                  ),
                ),
              ),

              const SizedBox(height: 30),
              Text(
                'Popular',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const gf()),
                        );
                      },
                      child: Image.asset('lib/images/godfather.jpg', height: 200),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const fc()),
                        );
                      },
                      child: Image.asset('lib/images/fc.jpg', height: 200),
                    ),
                    const SizedBox(width: 10),
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const br()),
                        );
                      },
                      child: Image.asset('lib/images/br.jpg', height: 200),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),
              Text(
                'New Releases',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const dune()),
                        );
                      },
                      child: Image.asset('lib/images/dune.jpeg', height: 200),
                    ),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/ca.jpeg', height: 200),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/m.jpeg', height: 200),
                  ],
                ),
              ),

              const SizedBox(height: 30),
              Text(
                'Animated',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => const op()),
                        );
                      },
                      child: Image.asset('lib/images/op.jpg', height: 200),
                    ),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/inv.jpeg', height: 200),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/wi.jpeg', height: 200),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
