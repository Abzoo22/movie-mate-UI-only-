import 'package:flutter/material.dart';
import 'package:test/pages/home.dart';
class Signup extends StatelessWidget{
  const Signup({super.key});

  @override
Widget build(BuildContext context){
return Scaffold(
  backgroundColor: Colors.grey[300]  ,
  body:SafeArea(
    child: Center(
      child: Column(
                mainAxisAlignment: MainAxisAlignment.center,

      children:[
        const SizedBox(height: 50,),
    Image.asset('lib/images/logo.jpg',height: 100,),

        const SizedBox(height: 50,),
        Text('welcome to movie mate  ',
        style: TextStyle(color:Colors.grey[700],
        fontSize:20 ),),
      const SizedBox(height: 25,),
      Text('Enter username',
        style: TextStyle(color:Colors.grey[700],
        fontSize:20 ),),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: TextField(
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white),),
          fillColor:Colors.grey.shade200,filled:true,
          ),
        ),
      ),

const SizedBox(height:30,),
Text('Enter E-mail',
        style: TextStyle(color:Colors.grey[700],
        fontSize:20 ),),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        child: TextField(
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white),),
          fillColor:Colors.grey.shade200,filled:true,
          ),
        ),
      ),
      const SizedBox(height:30,),
  Text('Enter password',
        style: TextStyle(color:Colors.grey[700],
        fontSize:20 ),),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25.0),
        
        child: TextField(
          decoration: InputDecoration(
            enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white),),
          fillColor:Colors.grey.shade200,filled:true,
          ),
        ),
      ),

      const SizedBox(height:20,),
        
      ElevatedButton(
        onPressed: () {
        Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const homepage()),);
  },
  style: ElevatedButton.styleFrom(
    backgroundColor: Colors.blue,
    padding: const EdgeInsets.symmetric(horizontal: 100, vertical: 15),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),),
  child: const Text('Sign In',style: TextStyle(color: Colors.white, fontSize: 16),),),


        const SizedBox(height:50,),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 25.0),
          child: Row(
            children: [
              Expanded(child: Divider(thickness: 1,color: Colors.grey[400],)),
              
              Expanded(child: Divider(thickness:1,color: Colors.grey[400],))
            ],
          ),
        ),
        const SizedBox(height:50,),
        

        
      ])
      ),
    ),
  )
;
}
}
