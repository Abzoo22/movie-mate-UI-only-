import 'package:flutter/material.dart';
import 'package:test/pages/home.dart';
import 'package:test/pages/profile.dart';

class watch extends StatelessWidget {
  const watch({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Colors.grey[300],
        elevation: 0,
        title: const Text(
          'Watchlist',
          style: TextStyle(color: Colors.black),
        ),
        actions: [
          PopupMenuButton<String>(
            icon: const Icon(Icons.menu, color: Colors.black),
            onSelected: (value) {
              if (value == 'profile') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const Profile()),
                );
              } else if (value == 'home') {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const homepage()),
                );
              } else if (value == 'logout') {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Logged out')),
                );
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(value: 'profile', child: Text('User Profile')),
              const PopupMenuItem(value: 'home', child: Text('Home')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
            
              Text(
                'Watching later',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Image.asset('lib/images/fc.jpg', height: 180),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/ca.jpeg', height: 180),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/wi.jpeg', height: 180),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              
              Text(
                'Watching',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Image.asset('lib/images/m.jpeg', height: 180),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/op.jpg', height: 180),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              Text(
                'Watched',
                style: TextStyle(
                  fontSize: 20,
                  color: Colors.grey[700],
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 15),
              SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: [
                    Image.asset('lib/images/godfather.jpg', height: 180),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/dune.jpeg', height: 180),
                    const SizedBox(width: 10),
                    Image.asset('lib/images/inv.jpeg', height: 180),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
