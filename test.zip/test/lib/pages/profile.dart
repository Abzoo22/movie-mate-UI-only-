import 'package:flutter/material.dart';

class Profile extends StatelessWidget {
  const Profile({super.key});
void genres(BuildContext context) {
  showDialog(
    context: context,
    builder: (context) {
      return SimpleDialog(
        title: const Text('Choose a Genre'),
        children: [
          genre(context, 'Action'),
          genre(context, 'Comedy'),
          genre(context, 'Drama'),
          genre(context, 'Horror'),
          genre(context, 'Sci-Fi'),
          genre(context, 'Romance'),
        ],
      );
    },
  );
}
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[300],
      appBar: AppBar(
        backgroundColor: Colors.grey[300],
        elevation: 0,
        title: const Text('Profile',style: TextStyle(color: Colors.black),
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              
              CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage('lib/images/user.jpg'), 
              ),
              const SizedBox(height: 20),

              
              Text(
                'Abdelrhman Zkria',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.grey[800],
                ),
              ),
              const SizedBox(height: 5),

              
              Text(
                'abdelrhman@gmail.com',
                style: TextStyle(
                  color: Colors.grey[600],
                  fontSize: 16,
                ),
              ),

              const SizedBox(height: 30),

              
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey[200],
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text(
                          'Movies Watched',
                          style: TextStyle(fontSize: 18),
                        ),
                        Text(
                          '12',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                    const Divider(height: 25, thickness: 1),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: const [
                        Text(
                          'Ratings Given',
                          style: TextStyle(fontSize: 18),
                        ),
                        Text(
                          '9 Movies',
                          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Your Ratings',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.grey[800],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 15),

              rating('The Godfather', 5),
              rating('Dune: Part Two', 4),
              rating('One Piece', 4),
              rating('Interstellar', 5),
              rating('Joker', 4),

              const SizedBox(height: 40),
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  'Based on your ratings',
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.grey[800],
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 15),
              ElevatedButton(
                      onPressed: () {
                        genres(context);
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 255, 0, 0),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                      ),
                      child: const Text(
                        'Generate Movies',
                        style: TextStyle(color: Colors.white),
                      ),),
                      ElevatedButton(
                      onPressed: () {
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color.fromARGB(255, 2, 61, 255),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 8),
                      ),
                      child: const Text(
                        'Share movies ',
                        style: TextStyle(color: Colors.white),
                      ),),
            ],
          ),
        ),
      ),
    );
  }
Widget genre(BuildContext context, String genre) {
  return SimpleDialogOption(
    onPressed: () {
      Navigator.pop(context);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Showing $genre movies')),
      );
    },
    child: Text(genre),
  );
}
  
  Widget rating(String movieTitle, int rating) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(movieTitle, style: TextStyle(fontSize: 16, color: Colors.grey[800])),
          Row(
            children: List.generate(5, (index) {
              return Icon(
                index < rating ? Icons.star : Icons.star_border,
                color: const Color.fromARGB(255, 255, 218, 6),
                size: 20,
              );
            }),
          ),
        ],
      ),
    );
  }
}
